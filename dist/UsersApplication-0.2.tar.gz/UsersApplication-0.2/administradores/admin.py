from django.contrib import admin
from .models import Administrador

admin.site.register(Administrador)

# Register your models here.
